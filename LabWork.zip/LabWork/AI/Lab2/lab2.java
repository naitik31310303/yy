package Lab2;

import java.util.*;
public class lab2 {

    static class State {
        int x, y;
        List<String> history;

        State(int x, int y, List<String> history) {
            this.x = x;
            this.y = y;
            this.history = history;
        }
    }

    static int encode(int x, int y, int j2) {
        return x * (j2 + 1) + y;
    }

    static List<String> addHistory(State s, int a, int b) {
        List<String> h = new ArrayList<>(s.history);
        h.add("(" + a + "," + b + ")");
        return h;
    }

    static State fillJ1(State s, int j1) {
        return new State(j1, s.y, addHistory(s, j1, s.y));
    }

    static State fillJ2(State s, int j2) {
        return new State(s.x, j2, addHistory(s, s.x, j2));
    }

    static State emptyJ1(State s) {
        return new State(0, s.y, addHistory(s, 0, s.y));
    }

    static State emptyJ2(State s) {
        return new State(s.x, 0, addHistory(s, s.x, 0));
    }

    static State transferJ1toJ2(State s, int j2) {
        int t = Math.min(s.x, j2 - s.y);
        return new State(s.x - t, s.y + t, addHistory(s, s.x - t, s.y + t));
    }

    static State transferJ2toJ1(State s, int j1) {
        int t = Math.min(s.y, j1 - s.x);
        return new State(s.x + t, s.y - t, addHistory(s, s.x + t, s.y - t));
    }

    static int gcd(int a, int b) {
        return b == 0 ? a : gcd(b, a % b);
    }

    static void bfs(int j1, int j2, int d) {

        if (d > Math.max(j1, j2) || d % gcd(j1, j2) != 0) {
            System.out.println("Not Possible");
            return;
        }

        boolean[] visited = new boolean[(j1 + 1) * (j2 + 1)];
        Queue<State> q = new LinkedList<>();

        List<String> h = new ArrayList<>();
        h.add("(0,0)");

        State start = new State(0, 0, h);
        q.add(start);
        visited[encode(0, 0, j2)] = true;

        while (!q.isEmpty()) {
            State cur = q.poll();

            if (cur.x == d || cur.y == d) {
                for (String s : cur.history)
                    System.out.print(s + " ");
                System.out.println();
                return;
            }

            State[] next = {
                    fillJ1(cur, j1),
                    fillJ2(cur, j2),
                    emptyJ1(cur),
                    emptyJ2(cur),
                    transferJ1toJ2(cur, j2),
                    transferJ2toJ1(cur, j1)
            };

            for (State n : next) {
                int id = encode(n.x, n.y, j2);
                if (!visited[id]) {
                    visited[id] = true;
                    q.add(n);
                }
            }
        }

        System.out.println("Not Possible");
    }

    public static void main(String[] args) {
        int j1 = 3;
        int j2 = 3;
        int d = 3;

        bfs(j1, j2, d);
    }
}
