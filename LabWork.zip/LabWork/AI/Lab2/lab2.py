from collections import deque

class State:
    def __init__(self, x, y, history):
        self.x = x
        self.y = y
        self.history = history

def encode(x, y, j2):
    return x * (j2 + 1) + y

def add_history(s, a, b):
    h = s.history.copy()
    h.append(f"({a},{b})")
    return h

def fillJ1(s, j1):
    return State(j1, s.y, add_history(s, j1, s.y))

def fillJ2(s, j2):
    return State(s.x, j2, add_history(s, s.x, j2))

def emptyJ1(s):
    return State(0, s.y, add_history(s, 0, s.y))

def emptyJ2(s):
    return State(s.x, 0, add_history(s, s.x, 0))

def transferJ1toJ2(s, j2):
    t = min(s.x, j2 - s.y)
    return State(s.x - t, s.y + t, add_history(s, s.x - t, s.y + t))

def transferJ2toJ1(s, j1):
    t = min(s.y, j1 - s.x)
    return State(s.x + t, s.y - t, add_history(s, s.x + t, s.y - t))

def gcd(a, b):
    return a if b == 0 else gcd(b, a % b)

def bfs(j1, j2, d):

    if d > max(j1, j2) or d % gcd(j1, j2) != 0:
        print("Not Possible")
        return

    visited = [False] * ((j1 + 1) * (j2 + 1))
    q = deque()

    start = State(0, 0, ["(0,0)"])
    q.append(start)
    visited[encode(0, 0, j2)] = True

    while q:
        cur = q.popleft()

        if cur.x == d or cur.y == d:
            print(" ".join(cur.history))
            return

        next_states = [
            fillJ1(cur, j1),
            fillJ2(cur, j2),
            emptyJ1(cur),
            emptyJ2(cur),
            transferJ1toJ2(cur, j2),
            transferJ2toJ1(cur, j1)
        ]

        for n in next_states:
            idx = encode(n.x, n.y, j2)
            if not visited[idx]:
                visited[idx] = True
                q.append(n)

    print("Not Possible")

if __name__ == "__main__":
    j1 = 3
    j2 = 3
    d = 3
    bfs(j1, j2, d)
