
function ar=cir_area(r)
r=input('Enter the radius of the circle: ') 
ar=pi*r*r;
disp('Area of the circle is:')
