const url = require('url');

const myUrl = new url.URL('http://localhost:3000/test?x=10');

console.log(myUrl.pathname);