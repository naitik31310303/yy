
const fs = require('fs');

fs.writeFileSync('test.txt', 'Hello File System');
console.log('File created');
