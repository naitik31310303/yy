const express = require('express');
const app = express();

app.get('/', (req, res) => {
    res.send('<h1>Home Page</h1><p>Welcome to Express</p>');
});

app.get('/about', (req, res) => {
    res.send('<h1>About Page</h1><p>This is about us</p>');
});

app.get('/services', (req, res) => {
    res.send('<h1>Services</h1><ul><li>Web</li><li>App</li><li>AI</li></ul>');
});

app.get('/contact', (req, res) => {
    res.send('<h1>Contact Page</h1><p>Email: test@gmail.com</p>');
});

app.get('/login', (req, res) => {
    res.send(`
        <h1>Login</h1>
        <form>
            <input type="text" placeholder="Username"><br><br>
            <input type="password" placeholder="Password"><br><br>
            <button>Login</button>
        </form>
    `);
});

app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
