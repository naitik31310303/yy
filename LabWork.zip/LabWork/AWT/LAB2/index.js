const express = require('express');
const path = require('path');
const app = express();
const port = 1337;

app.use(express.static('public'));

app.get('/html31', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'lab3-EX.html'));
});

app.listen(port, () => {
    console.log(`Server is listening on http://localhost:${port}`);
});
