const express = require("express");
const path = require("path");

const app = express();
const PORT = 3000;

app.use((req, res, next) => {
    console.log(`Request URL: ${req.url}`);
    next();
});

app.use(express.static(path.join(__dirname)));

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "i1.html"));
});

app.get("/i2", (req, res) => {
    res.sendFile(path.join(__dirname, "i2.html"));
});

app.get("/i3", (req, res) => {
    res.sendFile(path.join(__dirname, "i3.html"));
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
